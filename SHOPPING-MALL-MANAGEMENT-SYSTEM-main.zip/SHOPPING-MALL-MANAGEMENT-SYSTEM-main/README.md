# SHOPPING-MALL-MANAGEMENT-SYSTEM
Shopping mall management system to manage admin's and cashier's functionalities :)
